To extract textures from a FBX file, use AssetImporter.exe with the following syntax:

assetimporter node <filename>.fbx <filename>.xml

The textures will appear near your FBX model in a new Textures folder.

Apepeha Game Laboratory
apepehalab.github.io